"""
Agentic Site - Main FastAPI Application
A starter template for building AI-powered web applications
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import os
from typing import Optional, List
import uvicorn

# Initialize FastAPI app
app = FastAPI(
    title="Agentic Site",
    description="AI-powered web application",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this properly for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models
class ChatMessage(BaseModel):
    message: str
    user_id: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    message_id: str

class AgentConfig(BaseModel):
    name: str
    description: str
    model: str = "gpt-3.5-turbo"
    temperature: float = 0.7

# In-memory storage (replace with database in production)
conversations = {}
agents = {}

@app.get("/")
async def root():
    """Serve the main page"""
    return HTMLResponse(content="""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Agentic Site</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #333; text-align: center; }
            .chat-container { border: 1px solid #ddd; border-radius: 8px; height: 400px; overflow-y: auto; padding: 20px; margin: 20px 0; background: #fafafa; }
            .input-group { display: flex; gap: 10px; }
            input[type="text"] { flex: 1; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }
            button { padding: 12px 24px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
            button:hover { background: #0056b3; }
            .message { margin: 10px 0; padding: 10px; border-radius: 6px; }
            .user-message { background: #e3f2fd; text-align: right; }
            .agent-message { background: #f1f8e9; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🤖 Agentic Site</h1>
            <p style="text-align: center; color: #666;">Your AI-powered assistant is ready to help!</p>
            
            <div class="chat-container" id="chatContainer">
                <div class="message agent-message">
                    <strong>Agent:</strong> Hello! I'm your AI assistant. How can I help you today?
                </div>
            </div>
            
            <div class="input-group">
                <input type="text" id="messageInput" placeholder="Type your message here..." onkeypress="if(event.key==='Enter') sendMessage()">
                <button onclick="sendMessage()">Send</button>
            </div>
        </div>

        <script>
            async function sendMessage() {
                const input = document.getElementById('messageInput');
                const message = input.value.trim();
                if (!message) return;
                
                const chatContainer = document.getElementById('chatContainer');
                
                // Add user message
                chatContainer.innerHTML += `
                    <div class="message user-message">
                        <strong>You:</strong> ${message}
                    </div>
                `;
                
                input.value = '';
                chatContainer.scrollTop = chatContainer.scrollHeight;
                
                try {
                    const response = await fetch('/chat', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ message: message })
                    });
                    
                    const data = await response.json();
                    
                    // Add agent response
                    chatContainer.innerHTML += `
                        <div class="message agent-message">
                            <strong>Agent:</strong> ${data.response}
                        </div>
                    `;
                } catch (error) {
                    chatContainer.innerHTML += `
                        <div class="message agent-message">
                            <strong>Agent:</strong> Sorry, I encountered an error. Please try again.
                        </div>
                    `;
                }
                
                chatContainer.scrollTop = chatContainer.scrollHeight;
            }
        </script>
    </body>
    </html>
    """)

@app.post("/chat", response_model=ChatResponse)
async def chat(message: ChatMessage):
    """Handle chat messages"""
    try:
        # Simple echo response for now - replace with your AI logic
        response_text = f"I received your message: '{message.message}'. This is a placeholder response. Connect your AI model here!"
        
        return ChatResponse(
            response=response_text,
            message_id="msg_" + str(len(conversations))
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/agents")
async def list_agents():
    """List all available agents"""
    return {"agents": list(agents.keys())}

@app.post("/agents")
async def create_agent(config: AgentConfig):
    """Create a new agent"""
    agents[config.name] = config.dict()
    return {"message": f"Agent '{config.name}' created successfully"}

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "message": "Agentic site is running!"}

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
