# 🤖 Agentic Site

A modern, AI-powered web application built with FastAPI and designed for GitHub Codespaces.

## Features

- **AI Chat Interface**: Interactive chat with AI agents
- **Multiple AI Models**: Support for OpenAI GPT, Anthropic Claude, and more
- **Agent Management**: Create and configure custom AI agents
- **Modern Web UI**: Clean, responsive interface
- **Cloud-Ready**: Optimized for GitHub Codespaces deployment

## Quick Start with GitHub Codespaces

1. **Create a Codespace**:
   - Go to your GitHub repository
   - Click the green "Code" button
   - Select "Codespaces" tab
   - Click "Create codespace on main"

2. **Wait for Setup**:
   - The devcontainer will automatically install dependencies
   - This may take 2-3 minutes on first launch

3. **Configure Environment**:
   ```bash
   cp env.example .env
   # Edit .env with your API keys
   ```

4. **Run the Application**:
   ```bash
   cd agentic_site
   python main.py
   ```

5. **Access Your Site**:
   - Codespaces will automatically forward port 8000
   - Click the notification or go to the "Ports" tab
   - Your agentic site will open in a new browser tab

## Project Structure

```
agentic_site/
├── main.py              # FastAPI application
├── requirements_agentic.txt  # Python dependencies
├── .devcontainer/       # Codespaces configuration
│   └── devcontainer.json
└── env.example         # Environment variables template
```

## API Endpoints

- `GET /` - Main chat interface
- `POST /chat` - Send messages to AI agent
- `GET /agents` - List available agents
- `POST /agents` - Create new agent
- `GET /health` - Health check

## Development

### Adding AI Models

To integrate with OpenAI or Anthropic:

```python
import openai
from anthropic import Anthropic

# In your chat endpoint:
client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": message.message}]
)
```

### Database Integration

The starter includes SQLAlchemy setup. To add database models:

```python
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Conversation(Base):
    __tablename__ = "conversations"
    id = Column(Integer, primary_key=True)
    user_id = Column(String)
    message = Column(String)
    response = Column(String)
```

## Deployment Options

### GitHub Codespaces (Development)
- Perfect for development and testing
- Automatic environment setup
- Easy sharing and collaboration

### Production Deployment
- **Railway**: Connect your GitHub repo for auto-deployment
- **Render**: Free tier available with GitHub integration
- **Vercel**: Great for frontend + API deployment
- **AWS/GCP/Azure**: Full cloud deployment options

## Environment Variables

Copy `env.example` to `.env` and configure:

- `OPENAI_API_KEY`: Your OpenAI API key
- `ANTHROPIC_API_KEY`: Your Anthropic API key
- `DATABASE_URL`: Database connection string
- `SECRET_KEY`: Application secret key

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test in Codespaces
5. Submit a pull request

## License

MIT License - feel free to use this as a starting point for your agentic applications!

## Next Steps

1. **Add Authentication**: Implement user login/registration
2. **Connect AI Models**: Integrate OpenAI, Anthropic, or local models
3. **Add Vector Database**: Implement RAG (Retrieval Augmented Generation)
4. **Create Agents**: Build specialized AI agents for different tasks
5. **Add Memory**: Implement conversation history and context
6. **Deploy to Production**: Move from Codespaces to a production environment

Happy building! 🚀
